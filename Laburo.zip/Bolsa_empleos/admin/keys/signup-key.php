<?php
$username = $_POST['username'];
$numero = $_POST['number'];
$email = $_POST['email'];
$password = $_POST['password'];
$adname = "USUARIO";

$script_password = password_hash($password, PASSWORD_DEFAULT);

if(!empty($username) || !empty($numero) || !empty($email) || !empty($password)){
    $eso =  require('conection.php');
    if($eso){
        $SELECT = "SELECT * from USUARIO where UserName='$username' and Email = '$email'";
        $resultado = mysqli_query($conn,$SELECT);
        if($resultado->num_rows == 0){


            $INSERT = "INSERT INTO USUARIO (AdminName,Username,MobileNumber,Email,Password)values('$adname','$username','$numero','$email','$script_password')";
            $resultado = mysqli_query($conn,$INSERT);
            if($resultado){
                echo "REGISTRADO";
                $SELECT = "SELECT * FROM USUARIO WHERE Email = '$email'";
                $resultado = mysqli_query($conn,$SELECT);
                if($resultado){
                   
                    while($row = $resultado->fetch_array()){
                        $id = $row['ID'];
                        if(1==1){
                            // echo $row['id_registro'];
                            session_start();
                            $_SESSION['lssemsaid']=$id;
                            header("Location:../log-in.php");
                        }
                    }
                        
                    
                }
                else{
                    echo "NO HAY REGISTRO";
                }
            }
            else{
                echo "NO SE GUARDO EL REGISTRO";
            }
            
        }

        else{
            echo "email registrado";
            header("Location: ../register.php");

        }
        
    }
    else{
        echo "fallo la coneccion";
    }
}
else{
    echo "todos los datos son OBLIGATORIOS";
    die();
}
?>
