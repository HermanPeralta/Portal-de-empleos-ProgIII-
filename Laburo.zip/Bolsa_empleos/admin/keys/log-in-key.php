<?php

$username = $_POST['username'];
$password = $_POST['password'];


if(!empty($username) || !empty($password)){

    $eso =  require('conection.php');
    if($eso){
        $SELECT = "SELECT * from USUARIO where UserName='$username'";
        $resultado = mysqli_query($conn,$SELECT);

        if($resultado->num_rows == 1){
            $log = $resultado->fetch_array();
            echo "Log In Correcto";
            
            if(password_verify($password,$log['Password'])){
                echo $log['AdminName'];
                $id = $log['ID'];
                session_start();
                $_SESSION['lssemsaid']=$id;
                echo $id;
                if($log['AdminName']=="ADMIN"){
                    header("Location: ../dashboard.php");
                }
                else if($log['AdminName']=="POSTER"){
                    header("Location: ../administrar-trabajo1-Poster.php");
                }
                else if($log['AdminName']=="USUARIO"){
                    header("Location: ../../index.php");
                }
                
                
            }
            else{
                echo "La contraseña es incorrecta";
                echo "<script>
                alert('La contraseña es incorrecta');
                window.location='../log-in.php';
                </script>";
            }

        }
        else{
            
            echo "El usuario es incorrecto";
            echo "<script>
            alert('El usuario es incorrecto');
            window.location='../log-in.php';
            </script>";

        }
    }
    else{
        echo "la coneccionn de la base de  datos fallo";
    }
}
else{
    echo "todos los datos son OBLIGATORIOS";
    die();
}
?>
