<?php
$host = "localhost";
$dbusername = "root";
$dbpassword =  "";
$dbname = "bolsa_empleos";

$conn = new mysqli($host,$dbusername,$dbpassword,$dbname);

?>