<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['lssemsaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {

$eid=$_GET['editid'];
$adminName=$_POST['adminName'];
$userName=$_POST['userName'];
$mobileNumber=$_POST['mobileNumber'];
$email=$_POST['email'];

$sql="update USUARIO set AdminName=:admin,UserName=:userName,MobileNumber=:mobileNumber,Email=:email where ID=:eid";
$query=$dbh->prepare($sql);
$query->bindParam(':admin',$adminName,PDO::PARAM_STR);
$query->bindParam(':userName',$userName,PDO::PARAM_STR);
$query->bindParam(':mobileNumber',$mobileNumber,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':eid',$eid,PDO::PARAM_STR);
 $query->execute();

   $query->execute();

    echo '<script>alert("El usuario ha sido actualizado exitosamente!")</script>';

  }
  ?>
<!DOCTYPE html>
<html>
<head>
  
  <title>Laburo Web || Actualizar Trabajo</title>
  <link rel="shortcut icon" href="images/icono.ico" type="image/x-icon">
    
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php');?>

 


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Editar Trabajo</h1>
          </div>          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-dark">
              <div class="card-header">
                <h3 class="card-title">Actualizar Detalles</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" method="post" enctype="multipart/form-data">
                <?php
                   $eid=$_GET['editid'];
$sql="SELECT * from USUARIO where ID=$eid";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
                <div class="card-body">
                  <!-- <div class="form-group">
                    <label for="exampleInputEmail1">Categoría de Servicios</label>
                    <select type="text" name="category" id="category" value="" class="form-control" required="true">
<option value="?php echo htmlentities($row->Category);?>">?php echo htmlentities($row->Category);?></option>
                                                        ?php 

$sql2 = "SELECT * from CATEGORIA ";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$result2=$query2->fetchAll(PDO::FETCH_OBJ);

foreach($result2 as $row2)
{          
    ?>  
<option value="?php echo htmlentities($row2->Category);?>">?php echo htmlentities($row2->Category);?></option>
 ?php } ?>             
                                                        
                    </select>
                  </div> -->
                  
                  <!-- START MODIFICANDO -->
                  <?php
                   $eid=$_GET['editid'];
$sql4="SELECT * from USUARIO where ID=$eid";
$query4 = $dbh -> prepare($sql4);
$query4->execute();
$results4=$query4->fetchAll(PDO::FETCH_OBJ);

$cnt1=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>                                
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tipo Usuario</label>
                    <select type="text" name="adminName" id="adminName" value="" class="form-control" required="true">
<option value="<?php echo htmlentities($row->AdminName);?>"><?php echo htmlentities($row->AdminName);?></option>
                                                        <?php 

$sql3 = "SELECT * FROM TIPO_USUARIO";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$result3=$query3->fetchAll(PDO::FETCH_OBJ);

foreach($result3 as $row3)
{          
    ?>  
<option value="<?php echo htmlentities($row3->Tipo);?>"><?php echo htmlentities($row3->Tipo);?></option>
 <?php } ?>             
                                                        
                    </select>
                  </div>

                  <!-- END MODIFICANDO -->
                     <div class="form-group">
                    <label for="exampleInputEmail1">Nombre Usuario</label>
                    <input type="text" class="form-control" id="userName" name="userName" value="<?php echo htmlentities($row->UserName);?>" required="true">
                  </div>                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Número Movil</label>
                    <input type="text" class="form-control" id="mobileNumber" name="mobileNumber" value="<?php echo htmlentities($row->MobileNumber);?>" required="true">
                  </div> 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Correo Electrónico</label>
                    <textarea type="text" class="form-control" id="email" name="email" placeholder="Ubicacion" required="true"><?php echo htmlentities($row->Email);?></textarea>
                  </div>                                                    
                  <?php $cnt1=$cnt1+1;}} ?> 
              <?php $cnt=$cnt+1;}} ?> 
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" name="submit">Actualizar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
         
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
<?php include_once('includes/footer.php');?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>
<?php }  ?>