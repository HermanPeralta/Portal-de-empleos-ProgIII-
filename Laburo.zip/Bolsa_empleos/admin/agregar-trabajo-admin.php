<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['lssemsaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {

$lssemsaid=$_SESSION['lssemsaid'];
$descripcion=$_POST['descripcion'];
$posicion=$_POST['posicion'];
$ubicacion=$_POST['ubicacion'];
$compania=$_POST['compania'];
$category=$_POST['category'];
$tipo=$_POST['tipo'];
$url=$_POST['url'];
$estado=($_POST["estado"] == "activo") ? true : false;
$propic=$_FILES["propic"]["name"];
$extension = substr($propic,strlen($propic)-4,strlen($propic));
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Las fotos de perfil tienen un formato no válido. Solo se permite el formato jpg / jpeg / png / gif');</script>";
}
else
{

$propic=md5($propic).time().$extension;
 move_uploaded_file($_FILES["propic"]["tmp_name"],"images/".$propic);
$sql="insert into TRABAJO(Category,Tipo,Descripcion,Logo,Posicion,Ubicacion,Compania,Url,Estado)values(:cat,:tip,:descripcion,:log,:posicion,:ubicacion,:compania,:url,:estado)";
$query=$dbh->prepare($sql);
$query->bindParam(':descripcion',$descripcion,PDO::PARAM_STR);
$query->bindParam(':log',$propic,PDO::PARAM_STR);
$query->bindParam(':cat',$category,PDO::PARAM_STR);
$query->bindParam(':tip',$tipo,PDO::PARAM_STR);
$query->bindParam(':posicion',$posicion,PDO::PARAM_STR);
$query->bindParam(':ubicacion',$ubicacion,PDO::PARAM_STR);
$query->bindParam(':compania',$compania,PDO::PARAM_STR);
$query->bindParam(':url',$url,PDO::PARAM_STR);
$query->bindParam(':estado',$estado,PDO::PARAM_STR);
 $query->execute();

   $LastInsertId=$dbh->lastInsertId();
   if ($LastInsertId>0) {
    echo '<script>alert("Se ha agregado el empleo satisfactoriamente!")</script>';
echo "<script>window.location.href ='agregar-trabajo-admin.php'</script>";
  }
  else
    {
      echo '<script>alert("Algo salió mal. Por favor intentelo de nuevo!")</script>';
    }

  
}
}
?>
<!DOCTYPE html>
<html>
<head>
  
  <title>Laburo Web || Agregar Trabajo</title>
  <link rel="shortcut icon" href="images/icono.ico" type="image/x-icon">
    
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php');?>

 
<?php include_once('includes/sidebar.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Agregar Empleo</h1>
          </div>          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-dark" style="background-color: #08c2f3">
              <div class="card-header">
                <h3 class="card-title">Agregar</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Categoría del Servicio</label>
                    <select type="text" name="category" id="category" value="" class="form-control" required="true">
<option value="">Escoge Categoría</option>
                                                        <?php 

$sql2 = "SELECT * from CATEGORIA ";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$result2=$query2->fetchAll(PDO::FETCH_OBJ);

foreach($result2 as $row)
{          
    ?>  
<option value="<?php echo htmlentities($row->Category);?>"><?php echo htmlentities($row->Category);?></option>
 <?php } ?> 
            
                                                        
                                                    </select>
                  </div>
                  <!-- START MODIFICANDO -->
                  <!-- <div class="form-group">
                    <label for="exampleInputEmail1">Tipo del Servicio</label>
                    <select type="text" name="tipo" id="tipo" value="" class="form-control" required="true">
<option value="">Escoge Tipo</option>
                                                        ?php 

$sql3 = "SELECT * from TIPO_TRABAJO";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$result3=$query3->fetchAll(PDO::FETCH_OBJ);

foreach($result3 as $row)
{          
    ?>  
<option value="?php echo htmlentities($row->Tipo);?>">?php echo htmlentities($row->Tipo);?></option>
 ?php } ?> 
            
                                                        
                                                    </select>
                  </div> -->
                  <!-- END MODIFICANDO -->
                  
                  <!-- <div>
                        <label> Tipo de Servicio</label><br>
                        <input type="radio" name="tipo" value="Medio Tiempo">Medio Tiempo</input><br>
                        <input type="radio" name="tipo" value="Tiempo Completo">Tiempo Completo</input><br>
                        <input type="radio" name="tipo" value="Independiente">Independiente</input>
  
                  </div><br> -->
                  <label> Tipo de Servicio</label><br/>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tipo" value="Medio Tiempo">
                    <label class="form-check-label" for="inlineRadio1">Medio Tiempo</label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tipo" value="Tiempo Completo">
                    <label class="form-check-label" for="inlineRadio2">Tiempo Completo</label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="tipo" value="Independiente">
                    <label class="form-check-label" for="inlineRadio2">Independiente</label>
                  </div>
                  




                     <div class="form-group">
                    <label for="exampleInputEmail1">Descripcion</label>
                    <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" required="true">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Logo</label>
                    <input type="file" class="form-control" id="propic" name="propic" required="true">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Posicion</label>
                    <input type="text" class="form-control" id="posicion" name="posicion" placeholder="Posicion" required="true">
                  </div> 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Ubicacion</label>
                    <textarea type="text" class="form-control" id="ubicacion" name="ubicacion" placeholder="Ubicacion" required="true"></textarea>
                  </div> 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Compania</label>
                    <input type="text" class="form-control" id="compania" name="compania" placeholder="Compania" required="true">
                  </div>                  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Url</label>
                    <input type="text" class="form-control" id="url" name="url" placeholder="Url" required="true">
                  </div>
                  <!-- MODIFICANDO START1 -->
                  <div class="row">
                    <div class="col">
                      <div class="form-group">
                          <label class="form-check-label" for="estado">Activo</label>
                          <input class="form-check-input" type="checkbox" name="estado" value="activo" id="estado" checked>                          
                      </div>       
                    </div>
                  </div>
                  <!-- MODIFICANDO END1 -->
                <center>
                <div class="card-footer">
                  <button type="submit" class="btn btn-dark" name="submit">Agregar</button>
                </div>
                </center>
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
         
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
<?php include_once('includes/footer.php');?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>
<?php }  ?>