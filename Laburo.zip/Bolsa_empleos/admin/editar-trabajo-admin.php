<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['lssemsaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {

$eid=$_GET['editid'];
$descripcion=$_POST['descripcion'];
$posicion=$_POST['posicion'];
$ubicacion=$_POST['ubicacion'];
$category=$_POST['category'];
$tipo=$_POST['tipo'];
$compania=$_POST['compania'];
$estado=($_POST["estado"] == "activo") ? true : false;
$url=$_POST['url'];

$sql="update TRABAJO set Category=:cat,Tipo=:tip,Descripcion=:descripcion,Posicion=:posicion,Ubicacion=:ubicacion,Compania=:compania,Url=:url,Estado=:estado where ID=:eid";
$query=$dbh->prepare($sql);
$query->bindParam(':descripcion',$descripcion,PDO::PARAM_STR);
$query->bindParam(':cat',$category,PDO::PARAM_STR);
$query->bindParam(':tip',$tipo,PDO::PARAM_STR);
$query->bindParam(':posicion',$posicion,PDO::PARAM_STR);
$query->bindParam(':ubicacion',$ubicacion,PDO::PARAM_STR);
$query->bindParam(':compania',$compania,PDO::PARAM_STR);
$query->bindParam(':url',$url,PDO::PARAM_STR);
$query->bindParam(':estado',$estado,PDO::PARAM_STR);
$query->bindParam(':eid',$eid,PDO::PARAM_STR);
 $query->execute();

   $query->execute();

    echo '<script>alert("El trabajo ha sido editado exitosamente!")</script>';

  }
  ?>
<!DOCTYPE html>
<html>
<head>
  
  <title>Laburo Web || Actualizar Trabajo</title>
  <link rel="shortcut icon" href="images/icono.ico" type="image/x-icon">
    
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <?php include_once('includes/header.php');?>

 


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="margin-left:0;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Editar Trabajo</h1>
          </div>          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Actualizar Detalles de TRABAJO</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" method="post" enctype="multipart/form-data">
                <?php
                   $eid=$_GET['editid'];
$sql="SELECT * from TRABAJO where ID=$eid";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Categoría de Servicios</label>
                    <select type="text" name="category" id="category" value="" class="form-control" required="true">
<option value="<?php echo htmlentities($row->Category);?>"><?php echo htmlentities($row->Category);?></option>
                                                        <?php 

$sql2 = "SELECT * from CATEGORIA ";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$result2=$query2->fetchAll(PDO::FETCH_OBJ);

foreach($result2 as $row2)
{          
    ?>  
<option value="<?php echo htmlentities($row2->Category);?>"><?php echo htmlentities($row2->Category);?></option>
 <?php } ?>             
                                                        
                    </select>
                  </div>
                  
                  <!-- START MODIFICANDO -->
                  <?php
                   $eid=$_GET['editid'];
$sql4="SELECT * from TRABAJO where ID=$eid";
$query4 = $dbh -> prepare($sql4);
$query4->execute();
$results4=$query4->fetchAll(PDO::FETCH_OBJ);

$cnt1=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>                                
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tipo de Servicios</label>
                    <select type="text" name="tipo" id="tipo" value="" class="form-control" required="true">
<option value="<?php echo htmlentities($row->Tipo);?>"><?php echo htmlentities($row->Tipo);?></option>
                                                        <?php 

$sql3 = "SELECT * from TIPO_TRABAJO ";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$result3=$query3->fetchAll(PDO::FETCH_OBJ);

foreach($result3 as $row3)
{          
    ?>  
<option value="<?php echo htmlentities($row3->Tipo);?>"><?php echo htmlentities($row3->Tipo);?></option>
 <?php } ?>             
                                                        
                    </select>
                  </div>

                  <!-- END MODIFICANDO -->
                     <div class="form-group">
                    <label for="exampleInputEmail1">Descripcion</label>
                    <input type="text" class="form-control" id="descripcion" name="descripcion" value="<?php echo htmlentities($row->Descripcion);?>" required="true">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Logo</label>
                    <img src="images/<?php echo $row->Logo;?>" width="100" height="100" value="<?php  echo $row->Logo;?>">
                    <a href="cambiar-Imagen1.php?editid=<?php echo $row->ID;?>"> &nbsp; Editar Imagen</a>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Posicion</label>
                    <input type="text" class="form-control" id="posicion" name="posicion" value="<?php echo htmlentities($row->Posicion);?>" required="true">
                  </div> 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Ubicacion</label>
                    <textarea type="text" class="form-control" id="ubicacion" name="ubicacion" placeholder="Ubicacion" required="true"><?php echo htmlentities($row->Ubicacion);?></textarea>
                  </div>  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Compania</label>
                    <input type="text" class="form-control" id="compania" name="compania" value="<?php echo htmlentities($row->Compania);?>" required="true">
                  </div>                 
                  <div class="form-group">
                    <label for="exampleInputEmail1">Url</label>
                    <input type="text" class="form-control" id="url" name="url" value="<?php echo htmlentities($row->Url);?>" required="true">
                  </div>
                  <!-- MODIFICANDO START1 -->
                  <div class="row">
                    <div class="col">
                      <div class="form-group">
                        <label class="form-check-label" for="exampleInputEmail1">Activo</label>
                        <?php if($row->Estado==1): ?>
                          <input class="form-check-input" type="checkbox" name="estado" value="activo" id="estado" checked>
                        <?php else: ?>
                          <input class="form-check-input" type="checkbox" name="estado" value="activo" id="estado" >
                        <?php endif;?>
                      </div>      
                    </div>
                  </div>
                  <!-- MODIFICANDO END1 -->
                  <?php $cnt1=$cnt1+1;}} ?> 
              <?php $cnt=$cnt+1;}} ?> 
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" name="submit">Actualizar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
         
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
<?php include_once('includes/footer.php');?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>
<?php }  ?>