<!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="margin-left:0;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="dashboard.php" class="nav-link">Inicio</a>
      </li>
      
      <li class="nav-item d-none d-sm-inline-block">
        <a href="logout.php" class="nav-link" style="color:#08c2f3;">Salir</a>
      </li>
    </ul>

  </nav>
  <!-- /.navbar -->