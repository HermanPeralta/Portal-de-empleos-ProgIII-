<footer class="main-footer">
    <strong>Copyright &copy; 2021 </strong>
    Laburo Web
    
  </footer>