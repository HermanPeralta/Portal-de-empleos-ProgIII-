<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['lssemsaid'] == 0)) {
  header('location:logout.php');
} else {
  if (isset($_POST['submit'])) {

    $lssemsaid = $_SESSION['lssemsaid'];
    $adminName = $_POST['adminName'];
    $userName = $_POST['userName'];
    $mobileNumber = $_POST['mobileNumber'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "insert into USUARIO(AdminName,UserName,MobileNumber,Email,Password)values(:admin,:userName,:mobileNumber,:email,:password)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':admin', $adminName, PDO::PARAM_STR);
    $query->bindParam(':userName', $userName, PDO::PARAM_STR);
    $query->bindParam(':mobileNumber', $mobileNumber, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();

    $LastInsertId = $dbh->lastInsertId();
    if ($LastInsertId > 0) {
      echo '<script>alert("Se ha agregado el usuario satisfactoriamente!")</script>';
      echo "<script>window.location.href ='agregar-usuario-admin.php'</script>";
    } else {
      echo '<script>alert("Algo salió mal. Por favor intentelo de nuevo!")</script>';
    }


    //}
  }
?>
  <!DOCTYPE html>
  <html>

  <head>

    <title>Laburo Web || Agregar Usuario</title>
    <link rel="shortcut icon" href="images/icono.ico" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  </head>

  <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <?php include_once('includes/header.php'); ?>


      <?php include_once('includes/sidebar.php'); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Agregar Usuario</h1>
              </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row">
              <!-- left column -->
              <div class="col-md-12">
                <!-- general form elements -->
                <div class="card card-primary">
                  <div class="card-header">
                    <h3 class="card-title">Agregar Usuario</h3>
                  </div>
                  <!-- /.card-header -->
                  <!-- form start -->
                  <form role="form" method="post" enctype="multipart/form-data">
                    <div class="card-body">

                      <!-- START MODIFICANDO -->
                      <div class="form-group">
                        <label for="exampleInputEmail1">Tipo de Usuario</label>
                        <select type="text" name="adminName" id="adminName" value="" class="form-control" required="true">
                          <option value="">Escoge Tipo</option>
                          <?php

                          $sql3 = "SELECT * FROM trabajo";
                          $query3 = $dbh->prepare($sql3);
                          $query3->execute();
                          $result3 = $query3->fetchAll(PDO::FETCH_OBJ);

                          foreach ($result3 as $row) {
                          ?>
                            <option value="<?php echo htmlentities($row->Tipo); ?>"><?php echo htmlentities($row->Tipo); ?></option>
                          <?php } ?>


                        </select>
                      </div>
                      <!-- END MODIFICANDO -->
                      <div class="form-group">
                        <label for="exampleInputEmail1">Nombre Usuario</label>
                        <input type="text" class="form-control" id="userName" name="userName" placeholder="Nombre Usuario" required="true">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Número Móvil</label>
                        <input type="text" class="form-control" id="mobileNumber" name="mobileNumber" placeholder="Número Móvil" required="true">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Correo Electronico</label>
                        <input type="text" class="form-control" id="email" name="email" placeholder="Correo Electronico" required="true">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Contraseña</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña" required="true">
                      </div>

                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary" name="submit">Agregar</button>
                      </div>
                  </form>
                </div>
                <!-- /.card -->

              </div>
              <!--/.col (left) -->
              <!-- right column -->

            </div>
            <!-- /.row -->
          </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->

      <?php include_once('includes/footer.php'); ?>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- bs-custom-file-input -->
    <script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
        bsCustomFileInput.init();
      });
    </script>
  </body>

  </html>
<?php }  ?>