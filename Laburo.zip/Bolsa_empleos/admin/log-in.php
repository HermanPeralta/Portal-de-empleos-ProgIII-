<!DOCTYPE html>
<html>

<head>

  <title>Laburo Web</title>
  <link rel="shortcut icon" href="images/icono.ico" type="image/x-icon">


  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

</head>






<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
     
    </div>
    <!-- /.login-logo -->
    <div class="card">
      <div class="card-body login-card-body">
     <center> <a href="log-in.php" style="color:black"><font size="20" ><i><strong>LOGIN</strong></i></font></a></center>
        <p class="login-box-msg"><font face="georgia" style="color:black">Ingresa para iniciar tu sesión</font></p>

        <form action="keys/log-in-key.php" method="post" id="login">
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Usuario" required="true" name="username" value="<?php if (isset($_COOKIE["user_login"])) {
                                                                                                                    echo $_COOKIE["user_login"];
                                                                                                                  } ?>">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="password" class="form-control" placeholder="Contraseña" name="password" required="true" value="<?php if (isset($_COOKIE["userpassword"])) {
                                                                                                                          echo $_COOKIE["userpassword"];
                                                                                                                        } ?>">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-4">
              <button type="submit" name="login" class="btn btn-black btn-block" style="background-color:#08c2f3"><font face="georgia">Ingresar</font></button>
            </div>
          </div>
        </form>



        <p class="mb-1">
          <a href="forgot-password.php" ><font face="georgia">Olvidé mi contraseña</font></a>
        </p>
        <p><a href="register.php" ><font face="georgia">Registrate</font></a></p>

      </div>
      <!-- /.login-card-body -->
    </div>
  </div>
  <!-- /.login-box -->



  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>




<style>
  //
// Pages: Login & Register
//


.login-logo,
.register-logo {
  font-size: 2.1rem;
  font-weight: 600;
  margin-bottom: .9rem;
  text-align: center;

  a {
    color: $gray-700;
  }
}

.login-page,
.register-page {
  align-items: center;
  background: -webkit-linear-gradient(top, #08c2f3, white );
  display: flex;
  height: 100vh;
  justify-content: center;
}

.login-box,
.register-box {
  width: 360px;

  @media (max-width: map-get($grid-breakpoints, sm)) {
    margin-top: 20px;
    width: 90%;
  }
}

.login-card-body,
.register-card-body {
  background: $white;
  border-top: 0;
  color: #666;
  padding: 20px;

  .input-group {
    .form-control {
      border-right: 0;

      &:focus {
        box-shadow: none;

        & ~ .input-group-append .input-group-text {
          border-color: $input-focus-border-color;
        }
      }

      &.is-valid {
        &:focus {
          box-shadow: none;
        }

        & ~ .input-group-append .input-group-text {
          border-color: $success;
        }
      }

      &.is-invalid {
        &:focus {
          box-shadow: none;
        }

        & ~ .input-group-append .input-group-text {
          border-color: $danger;
        }
      }
    }

    .input-group-text {
      background-color: transparent;
      border-bottom-right-radius: $border-radius;
      border-left: 0;
      border-top-right-radius: $border-radius;
      color: #777;
      transition: $input-transition;
    }
  }
}

.login-box-msg,
.register-box-msg {
  margin: 0;
  padding: 0 20px 20px;
  text-align: center;
}

.social-auth-links {
  margin: 10px 0;
}

</style>
</body>

</html>